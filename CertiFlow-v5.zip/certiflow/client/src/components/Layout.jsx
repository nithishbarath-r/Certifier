import { useState } from 'react';
import { NavLink, Outlet } from 'react-router';
import { Award, CalendarDays, LayoutGrid, LogOut, Menu, Settings, ShieldCheck, X } from 'lucide-react';
import { useAuth } from '../lib/auth.jsx';
import { cx } from './ui.jsx';

const NAV = [
  { to: '/', label: 'Overview', icon: LayoutGrid, end: true },
  { to: '/events', label: 'Events', icon: CalendarDays },
  { to: '/certificates', label: 'Certificates', icon: Award },
  { to: '/settings', label: 'Settings', icon: Settings },
];

export function Logo({ light }) {
  return (
    <span className="flex items-center gap-2.5">
      <img src="/favicon.svg" alt="" className="size-8" />
      <span className={cx('font-serif text-[1.35rem] font-semibold tracking-tight', light ? 'text-white' : 'text-ink')}>CertiFlow</span>
    </span>
  );
}

export default function Layout() {
  const { admin, logout } = useAuth();
  const [open, setOpen] = useState(false);

  const nav = (
    <nav className="flex flex-col gap-1">
      {NAV.map(({ to, label, icon: Icon, end }) => (
        <NavLink
          key={to}
          to={to}
          end={end}
          onClick={() => setOpen(false)}
          className={({ isActive }) =>
            cx(
              'flex items-center gap-3 rounded-lg px-3 py-2.5 text-[15px] transition-colors',
              isActive ? 'bg-white/12 font-semibold text-white' : 'text-white/70 hover:bg-white/6 hover:text-white'
            )
          }
        >
          <Icon className="size-[18px]" strokeWidth={2} />
          {label}
        </NavLink>
      ))}
      <a
        href="/verify"
        target="_blank"
        rel="noreferrer"
        className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-[15px] text-white/70 hover:bg-white/6 hover:text-white"
      >
        <ShieldCheck className="size-[18px]" strokeWidth={2} />
        Public verify page
      </a>
    </nav>
  );

  const account = (
    <div className="border-t border-white/10 pt-4">
      <p className="truncate text-sm font-medium text-white">{admin?.name}</p>
      <p className="truncate text-xs text-white/55">{admin?.email}</p>
      <button type="button" onClick={logout} className="mt-3 flex items-center gap-2 text-sm text-white/70 hover:text-white">
        <LogOut className="size-4" /> Log out
      </button>
    </div>
  );

  return (
    <div className="min-h-screen lg:pl-64">
      {/* Desktop sidebar */}
      <aside className="no-print fixed inset-y-0 left-0 hidden w-64 bg-ink lg:flex">
        <div className="w-[6px] bg-blue" />
        <div className="w-[3px] bg-gold" />
        <div className="flex flex-1 flex-col gap-8 px-5 py-6">
          <Logo light />
          <div className="flex-1">{nav}</div>
          {account}
        </div>
      </aside>

      {/* Mobile top bar */}
      <div className="no-print sticky top-0 z-40 flex items-center justify-between border-b border-line bg-paper px-4 py-3 lg:hidden">
        <Logo />
        <button type="button" onClick={() => setOpen(true)} className="rounded-md p-2 text-ink" aria-label="Open menu">
          <Menu className="size-5" />
        </button>
      </div>
      {open ? (
        <div className="fixed inset-0 z-50 bg-ink/40 lg:hidden" onClick={() => setOpen(false)}>
          <div className="flex h-full w-72 flex-col gap-8 bg-ink px-5 py-6" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <Logo light />
              <button type="button" onClick={() => setOpen(false)} className="text-white/70" aria-label="Close menu">
                <X className="size-5" />
              </button>
            </div>
            <div className="flex-1">{nav}</div>
            {account}
          </div>
        </div>
      ) : null}

      <main className="mx-auto max-w-6xl px-4 py-8 sm:px-8 lg:py-10">
        <Outlet />
      </main>
    </div>
  );
}
