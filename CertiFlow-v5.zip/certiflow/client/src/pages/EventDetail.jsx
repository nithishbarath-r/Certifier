import { useCallback, useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router';
import { ArrowLeft, Copy, Download, ExternalLink, FileDown, Pencil, Printer, QrCode, Trash2 } from 'lucide-react';
import { api, downloadFile, errorMessage, openPdf } from '../lib/api.js';
import { fmtDate, fmtDateTime, plural } from '../lib/format.js';
import { Badge, Button, Card, DeliveryBadge, EmptyState, ErrorNote, Spinner, cx, useToast } from '../components/ui.jsx';
import EventForm from '../components/EventForm.jsx';
import DesignCard from '../components/DesignCard.jsx';

const REVIEWS = ['Excellent', 'Very Good', 'Good', 'Average', 'Poor'];

function QrPanel({ event }) {
  const toast = useToast();
  const [qr, setQr] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get(`/events/${event._id}/qr`).then((r) => setQr(r.data)).catch((e) => setError(errorMessage(e)));
  }, [event._id, event.name]);

  if (error) {
    return (
      <Card className="p-6">
        <QrCode className="size-7 text-faint" />
        <p className="mt-3 font-semibold">QR code not ready</p>
        <p className="mt-1 text-sm text-muted">{error}</p>
        <Link to="/settings"><Button size="sm" className="mt-4">Open Settings</Button></Link>
      </Card>
    );
  }
  if (!qr) return <Card><Spinner /></Card>;

  return (
    <Card className="overflow-hidden">
      {/* Printable poster: only this block shows when printing */}
      <div id="qr-poster" className="p-6 text-center">
        <p className="font-serif text-xl font-semibold">{event.name}</p>
        <p className="mt-1 text-sm text-muted">Scan to share feedback and get your certificate</p>
        <img src={qr.qrDataUrl} alt={`QR code for ${event.name} feedback form`} className="mx-auto mt-4 w-full max-w-[240px]" />
      </div>
      <div className="no-print grid grid-cols-2 gap-2 border-t border-line p-4">
        <a href={qr.qrDataUrl} download={`${event.slug}-qr.png`}>
          <Button size="sm" variant="secondary" icon={Download} className="w-full">Save QR</Button>
        </a>
        <Button size="sm" variant="secondary" icon={Printer} onClick={() => window.print()}>Print poster</Button>
        <Button
          size="sm"
          variant="secondary"
          icon={Copy}
          onClick={() => navigator.clipboard.writeText(qr.formLink).then(() => toast('Form link copied'))}
        >
          Copy link
        </Button>
        <a href={qr.formLink} target="_blank" rel="noreferrer">
          <Button size="sm" variant="secondary" icon={ExternalLink} className="w-full">Open form</Button>
        </a>
      </div>
    </Card>
  );
}

function Bars({ title, rows, total }) {
  return (
    <div>
      <p className="mb-3 text-sm font-medium text-muted">{title}</p>
      <ul className="space-y-2">
        {rows.map(([label, n]) => (
          <li key={label} className="grid grid-cols-[88px_1fr_28px] items-center gap-3 text-sm">
            <span className="text-ink-soft">{label}</span>
            <span className="h-2.5 overflow-hidden rounded-full bg-canvas">
              <span className="block h-full rounded-full bg-blue" style={{ width: total ? `${(n / total) * 100}%` : 0 }} />
            </span>
            <span className="text-right tabular-nums text-muted">{n}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default function EventDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const toast = useToast();
  const [event, setEvent] = useState(null);
  const [fb, setFb] = useState(null);
  const [error, setError] = useState('');
  const [editing, setEditing] = useState(false);
  const [busy, setBusy] = useState('');

  const load = useCallback(async () => {
    try {
      const [e, f] = await Promise.all([api.get(`/events/${id}`), api.get(`/events/${id}/feedback`)]);
      setEvent(e.data.event);
      setFb(f.data);
    } catch (err) {
      setError(errorMessage(err));
    }
  }, [id]);

  useEffect(() => {
    load();
  }, [load]);

  async function toggleOpen() {
    setBusy('toggle');
    try {
      const { data } = await api.patch(`/events/${id}`, { feedbackOpen: !event.feedbackOpen });
      setEvent(data.event);
      toast(data.event.feedbackOpen ? 'Feedback reopened' : 'Feedback closed. New responses will not get certificates.');
    } catch (err) {
      toast(errorMessage(err), 'bad');
    } finally {
      setBusy('');
    }
  }

  async function remove() {
    if (!window.confirm(`Delete "${event.name}"? This cannot be undone.`)) return;
    try {
      await api.delete(`/events/${id}`);
      toast('Event deleted');
      navigate('/events');
    } catch (err) {
      toast(errorMessage(err), 'bad');
    }
  }

  if (error) return <ErrorNote>{error}</ErrorNote>;
  if (!event || !fb) return <Spinner />;
  const a = fb.analytics;

  return (
    <>
      <div className="no-print">
        <Link to="/events" className="mb-4 inline-flex items-center gap-1.5 text-sm font-medium text-muted hover:text-ink">
          <ArrowLeft className="size-4" /> All events
        </Link>
        <header className="mb-7 flex flex-wrap items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-3">
              <h1 className="font-serif text-[2rem] font-semibold leading-tight tracking-tight">{event.name}</h1>
              {event.feedbackOpen ? <Badge tone="ok">Feedback open</Badge> : <Badge>Feedback closed</Badge>}
            </div>
            <p className="mt-1.5 text-[15px] text-muted">
              {event.organizer}, {fmtDate(event.date)}
              {event.venue ? `, ${event.venue}` : ''}
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="secondary" icon={Pencil} onClick={() => setEditing(true)}>Edit</Button>
            <Button variant="secondary" loading={busy === 'toggle'} onClick={toggleOpen}>
              {event.feedbackOpen ? 'Close feedback' : 'Reopen feedback'}
            </Button>
            {event.stats.certificatesIssued === 0 ? (
              <Button variant="danger" icon={Trash2} onClick={remove}>Delete</Button>
            ) : null}
          </div>
        </header>
      </div>

      <div className="grid gap-6 lg:grid-cols-[320px_1fr]">
        <div className="space-y-6">
          <QrPanel event={event} />
        </div>

        <div className="no-print space-y-6">
          <Card className="p-6">
            <div className="flex flex-wrap gap-x-10 gap-y-4">
              <div>
                <p className="text-sm text-muted">Responses</p>
                <p className="font-serif text-4xl font-semibold tabular-nums">{a.total}</p>
              </div>
              <div>
                <p className="text-sm text-muted">Average rating</p>
                <p className="font-serif text-4xl font-semibold tabular-nums">
                  {a.averageRating ?? '–'}
                  <span className="text-lg text-faint"> / 5</span>
                </p>
              </div>
              <div>
                <p className="text-sm text-muted">Certificates</p>
                <p className="font-serif text-4xl font-semibold tabular-nums">{event.stats.certificatesIssued}</p>
              </div>
              <div>
                <p className="text-sm text-muted">Colleges</p>
                <p className="font-serif text-4xl font-semibold tabular-nums">{a.colleges}</p>
              </div>
            </div>
            {a.total ? (
              <div className="mt-6 grid gap-8 border-t border-line pt-6 md:grid-cols-2">
                <Bars title="How was the event?" rows={REVIEWS.map((r) => [r, a.reviewCounts[r] || 0])} total={a.total} />
                <Bars title="Rating" rows={[5, 4, 3, 2, 1].map((r) => [`${r} star${r > 1 ? 's' : ''}`, a.ratingCounts[r - 1]])} total={a.total} />
              </div>
            ) : null}
          </Card>

          <Card>
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line px-6 py-4">
              <h2 className="font-semibold">Participants</h2>
              {fb.feedback.length ? (
                <Button
                  size="sm"
                  variant="secondary"
                  icon={FileDown}
                  onClick={() => downloadFile(`/events/${id}/export.csv`, `${event.slug}-feedback.csv`).catch((e) => toast(errorMessage(e), 'bad'))}
                >
                  Export to Excel (CSV)
                </Button>
              ) : null}
            </div>
            {fb.feedback.length ? (
              <ul className="divide-y divide-line">
                {fb.feedback.map((f) => (
                  <li key={f._id} className="grid gap-2 px-6 py-4 sm:grid-cols-[1fr_auto]">
                    <div className="min-w-0">
                      <p className="font-medium">
                        {f.participant.name} <span className="font-normal text-muted">{f.participant.regNo}</span>
                      </p>
                      <p className="truncate text-sm text-muted">{f.participant.college}, {f.participant.email}</p>
                      <p className="mt-1 text-sm">
                        <span className="font-medium text-gold">{'★'.repeat(f.rating)}</span>
                        <span className="text-line">{'★'.repeat(5 - f.rating)}</span>
                        <span className="ml-2 text-ink-soft">{f.review}</span>
                        {f.comments ? <span className="text-muted">: “{f.comments}”</span> : null}
                      </p>
                    </div>
                    <div className="flex items-center gap-3 sm:flex-col sm:items-end">
                      {f.certificate ? (
                        <>
                          <DeliveryBadge cert={f.certificate} />
                          <button
                            type="button"
                            className={cx('text-sm font-medium text-blue hover:underline')}
                            onClick={() => openPdf(`/certificates/${f.certificate._id}/download?inline=1`).catch((e) => toast(errorMessage(e), 'bad'))}
                          >
                            {f.certificate.certificateId}
                          </button>
                        </>
                      ) : (
                        <Badge tone="warn">No certificate</Badge>
                      )}
                      <span className="text-xs text-faint">{fmtDateTime(f.submittedAt)}</span>
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <EmptyState title="No feedback yet">
                Show the QR code at the end of the event. Responses appear here within {plural(30, 'second')}.
              </EmptyState>
            )}
          </Card>
        </div>
      </div>

      <div className="no-print mt-6">
        <DesignCard event={event} />
      </div>

      <EventForm
        open={editing}
        event={event}
        onClose={() => setEditing(false)}
        onSaved={(data) => {
          setEditing(false);
          setEvent(data.event);
          toast('Changes saved. New certificates will use them.');
        }}
      />

      <style>{`@media print { #qr-poster { padding-top: 15vh } #qr-poster p:first-child { font-size: 32px } #qr-poster img { max-width: 420px } }`}</style>
    </>
  );
}
