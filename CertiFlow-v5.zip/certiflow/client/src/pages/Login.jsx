import { useEffect, useState } from 'react';
import { Navigate, useLocation, useNavigate } from 'react-router';
import { api, errorMessage } from '../lib/api.js';
import { useAuth } from '../lib/auth.jsx';
import { Button, ErrorNote, Field, Input } from '../components/ui.jsx';
import { Logo } from '../components/Layout.jsx';

const STEPS = [
  ['Participants scan the event QR code', 'It opens your Google Form with the event already filled in.'],
  ['They share feedback', 'Name, register number, college, email and a quick review.'],
  ['Their certificate arrives by email', 'A PDF with a unique ID that anyone can verify.'],
];

export default function Login() {
  const { admin, login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [hint, setHint] = useState(null);

  useEffect(() => {
    api.get('/auth/bootstrap').then((r) => setHint(r.data.defaultLogin)).catch(() => {});
  }, []);

  if (admin) return <Navigate to="/" replace />;

  async function submit(e) {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      await login(email, password);
      navigate(location.state?.from || '/', { replace: true });
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="grid min-h-screen lg:grid-cols-[1.1fr_1fr]">
      <div className="relative hidden overflow-hidden bg-ink px-14 py-12 text-white lg:flex lg:flex-col">
        <div className="absolute inset-y-0 left-0 flex">
          <div className="w-[10px] bg-blue" />
          <div className="w-[4px] bg-gold" />
        </div>
        <Logo light />
        <div className="my-auto max-w-md">
          <h1 className="font-serif text-[2.6rem] font-semibold leading-[1.15]">
            Feedback in.
            <br />
            Certificates out.
          </h1>
          <ol className="mt-10 space-y-6">
            {STEPS.map(([title, text], i) => (
              <li key={title} className="flex gap-4">
                <span className="flex size-8 shrink-0 items-center justify-center rounded-full border border-gold/60 font-serif text-gold">
                  {i + 1}
                </span>
                <div>
                  <p className="font-semibold">{title}</p>
                  <p className="mt-0.5 text-sm text-white/65">{text}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </div>

      <div className="flex items-center justify-center px-5 py-12">
        <form onSubmit={submit} className="w-full max-w-sm">
          <div className="mb-8 lg:hidden">
            <Logo />
          </div>
          <h2 className="font-serif text-3xl font-semibold">Coordinator login</h2>
          <p className="mt-1.5 text-[15px] text-muted">Manage events, feedback and certificates.</p>

          <div className="mt-8 space-y-4">
            <Field label="Email">
              <Input type="email" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} required />
            </Field>
            <Field label="Password">
              <Input type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} required />
            </Field>
            <ErrorNote>{error}</ErrorNote>
            <Button type="submit" loading={busy} className="w-full">
              Log in
            </Button>
          </div>

          {hint ? (
            <div className="mt-8 rounded-lg border border-gold/30 bg-gold-wash p-4 text-sm">
              <p className="font-semibold text-ink">First time here?</p>
              <p className="mt-1 text-ink-soft">
                Log in with <b>{hint.email}</b> and password <b>{hint.password}</b>, then change the password in Settings.
              </p>
              <button
                type="button"
                className="mt-2 font-semibold text-blue hover:underline"
                onClick={() => {
                  setEmail(hint.email);
                  setPassword(hint.password);
                }}
              >
                Fill in for me
              </button>
            </div>
          ) : null}
        </form>
      </div>
    </div>
  );
}
