import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { BadgeCheck, Search, ShieldX } from 'lucide-react';
import { api, errorMessage } from '../lib/api.js';
import { fmtDate } from '../lib/format.js';
import { Button, Input, Spinner } from '../components/ui.jsx';
import { Logo } from '../components/Layout.jsx';

function Row({ label, value }) {
  return (
    <div className="grid grid-cols-[120px_1fr] gap-3 py-2.5 text-[15px]">
      <dt className="text-muted">{label}</dt>
      <dd className="font-medium text-ink">{value}</dd>
    </div>
  );
}

export default function Verify() {
  const { certificateId } = useParams();
  const navigate = useNavigate();
  const [input, setInput] = useState(certificateId || '');
  const [state, setState] = useState({ status: certificateId ? 'loading' : 'idle' });

  useEffect(() => {
    if (!certificateId) {
      setState({ status: 'idle' });
      return;
    }
    setInput(certificateId);
    setState({ status: 'loading' });
    api
      .get(`/public/verify/${encodeURIComponent(certificateId)}`)
      .then((r) => setState({ status: r.data.valid ? 'valid' : 'revoked', cert: r.data.certificate }))
      .catch((err) => setState({ status: 'invalid', message: errorMessage(err) }));
  }, [certificateId]);

  const submit = (e) => {
    e.preventDefault();
    const id = input.trim().toUpperCase();
    if (id) navigate(`/verify/${id}`);
  };

  const { status, cert } = state;

  return (
    <div className="min-h-screen bg-canvas">
      <div className="edge-band h-1.5" />
      <div className="mx-auto max-w-xl px-5 py-10">
        <Logo />
        <h1 className="mt-10 font-serif text-[2rem] font-semibold leading-tight">Check a certificate</h1>
        <p className="mt-1.5 text-[15px] text-muted">Enter the ID printed at the bottom left of the certificate, or scan its QR code.</p>

        <form onSubmit={submit} className="mt-6 flex gap-2">
          <Input value={input} onChange={(e) => setInput(e.target.value)} placeholder="CF-2026-7K3QXM" aria-label="Certificate ID" className="uppercase" />
          <Button type="submit" icon={Search}>Check</Button>
        </form>

        <div className="mt-8">
          {status === 'loading' ? <Spinner label="Checking" /> : null}

          {status === 'valid' || status === 'revoked' ? (
            <section className="overflow-hidden rounded-xl border border-line bg-paper">
              <div className={`flex items-center gap-3 px-6 py-5 ${status === 'valid' ? 'bg-ok-wash' : 'bg-bad-wash'}`}>
                {status === 'valid' ? <BadgeCheck className="size-8 text-ok" /> : <ShieldX className="size-8 text-bad" />}
                <div>
                  <p className={`text-lg font-semibold ${status === 'valid' ? 'text-ok' : 'text-bad'}`}>
                    {status === 'valid' ? 'This certificate is genuine' : 'This certificate has been revoked'}
                  </p>
                  <p className="text-sm text-ink-soft">
                    {status === 'valid' ? `Issued by ${cert.organizer}` : `${cert.organizer} has withdrawn it. It is no longer valid.`}
                  </p>
                </div>
              </div>
              <dl className="divide-y divide-line px-6 py-2">
                <Row label="Awarded to" value={cert.name} />
                <Row label="Register no." value={cert.regNo} />
                <Row label="College" value={cert.college} />
                <Row label="Event" value={cert.event} />
                <Row label="Event date" value={fmtDate(cert.eventDate)} />
                <Row label="Issued on" value={fmtDate(cert.issuedAt)} />
                <Row label="Certificate ID" value={cert.certificateId} />
              </dl>
            </section>
          ) : null}

          {status === 'invalid' ? (
            <section className="flex items-start gap-3 rounded-xl border border-bad/20 bg-paper px-6 py-5">
              <ShieldX className="mt-0.5 size-6 shrink-0 text-bad" />
              <div>
                <p className="font-semibold text-bad">Not a valid certificate</p>
                <p className="mt-0.5 text-[15px] text-ink-soft">{state.message}. Check the ID for typos.</p>
              </div>
            </section>
          ) : null}
        </div>
      </div>
    </div>
  );
}
