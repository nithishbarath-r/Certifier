import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router';
import { AlertTriangle, CalendarPlus, Link2, RefreshCw } from 'lucide-react';
import { api, errorMessage } from '../lib/api.js';
import { fmtDate, plural, timeAgo } from '../lib/format.js';
import { Badge, Button, Card, DeliveryBadge, EmptyState, ErrorNote, PageHeader, Select, Spinner, useToast } from '../components/ui.jsx';

function Pipeline({ counts }) {
  const steps = [
    { n: counts.feedback, label: 'Feedback received', sub: `across ${plural(counts.events, 'event')}` },
    { n: counts.certificates, label: 'Certificates issued', sub: 'stored with their PDF' },
    {
      n: counts.emailed,
      label: 'Emailed to participants',
      sub: counts.emailFailed ? `${counts.emailFailed} failed to send` : counts.emailPending ? `${counts.emailPending} sending` : 'all delivered',
      warn: counts.emailFailed > 0,
    },
  ];
  return (
    <Card className="overflow-hidden">
      <div className="edge-band h-1" />
      <ol className="grid divide-y divide-line sm:grid-cols-3 sm:divide-x sm:divide-y-0">
        {steps.map((s, i) => (
          <li key={s.label} className="relative px-6 py-6">
            <p className="text-sm font-medium text-muted">
              <span className="mr-2 text-gold">{i + 1}</span>
              {s.label}
            </p>
            <p className="mt-2 font-serif text-5xl font-semibold tabular-nums tracking-tight text-ink">{s.n}</p>
            <p className={`mt-1 text-sm ${s.warn ? 'font-medium text-bad' : 'text-muted'}`}>{s.sub}</p>
          </li>
        ))}
      </ol>
    </Card>
  );
}

function ConnectBanner() {
  return (
    <Card className="mb-6 flex flex-wrap items-center justify-between gap-4 border-gold/40 bg-gold-wash px-6 py-5">
      <div>
        <p className="font-semibold text-ink">Connect your Google Form to start collecting feedback</p>
        <p className="mt-0.5 text-sm text-ink-soft">It takes about three minutes. CertiFlow creates the form for you.</p>
      </div>
      <Link to="/settings">
        <Button icon={Link2}>Connect Google Form</Button>
      </Link>
    </Card>
  );
}

function Issues({ issues, events, onChanged }) {
  const toast = useToast();
  const [choice, setChoice] = useState({});
  const [busy, setBusy] = useState(null);

  async function assign(issue) {
    setBusy(issue._id);
    try {
      await api.post(`/dashboard/issues/${issue._id}/assign`, { eventId: choice[issue._id] });
      toast(`Certificate issued to ${issue.answers?.name || 'participant'}`);
      onChanged();
    } catch (err) {
      toast(errorMessage(err), 'bad');
    } finally {
      setBusy(null);
    }
  }
  async function dismiss(issue) {
    setBusy(issue._id);
    try {
      await api.post(`/dashboard/issues/${issue._id}/dismiss`);
      onChanged();
    } finally {
      setBusy(null);
    }
  }

  return (
    <Card className="mt-6">
      <div className="flex items-center gap-2 border-b border-line px-6 py-4">
        <AlertTriangle className="size-5 text-warn" />
        <h2 className="font-semibold">Responses that need you</h2>
        <Badge tone="warn">{issues.length}</Badge>
      </div>
      <ul className="divide-y divide-line">
        {issues.map((issue) => (
          <li key={issue._id} className="flex flex-wrap items-center gap-4 px-6 py-4">
            <div className="min-w-56 flex-1">
              <p className="font-medium">
                {issue.answers?.name || 'Unnamed'} <span className="font-normal text-muted">({issue.answers?.regNo || 'no reg. no'})</span>
              </p>
              <p className="text-sm text-warn">{issue.reason}</p>
            </div>
            {issue.code === 'unknown_event' || issue.code === 'feedback_closed' ? (
              <div className="flex items-center gap-2">
                <Select
                  className="h-8 w-52 text-sm"
                  value={choice[issue._id] || ''}
                  onChange={(e) => setChoice({ ...choice, [issue._id]: e.target.value })}
                  aria-label="Choose event"
                >
                  <option value="">Choose the right event</option>
                  {events.map((ev) => (
                    <option key={ev._id} value={ev._id}>{ev.name}</option>
                  ))}
                </Select>
                <Button size="sm" disabled={!choice[issue._id]} loading={busy === issue._id} onClick={() => assign(issue)}>
                  Issue certificate
                </Button>
              </div>
            ) : null}
            <Button size="sm" variant="ghost" disabled={busy === issue._id} onClick={() => dismiss(issue)}>
              Dismiss
            </Button>
          </li>
        ))}
      </ul>
    </Card>
  );
}

export default function Dashboard() {
  const toast = useToast();
  const [data, setData] = useState(null);
  const [allEvents, setAllEvents] = useState([]);
  const [error, setError] = useState('');
  const [syncing, setSyncing] = useState(false);

  const load = useCallback(async () => {
    try {
      const [d, e] = await Promise.all([api.get('/dashboard'), api.get('/events')]);
      setData(d.data);
      setAllEvents(e.data.events);
      setError('');
    } catch (err) {
      setError(errorMessage(err));
    }
  }, []);

  useEffect(() => {
    load();
    const t = setInterval(load, 15000);
    return () => clearInterval(t);
  }, [load]);

  async function syncNow() {
    setSyncing(true);
    try {
      const { data: r } = await api.post('/settings/sync');
      if (r.result.error) toast(r.result.error, 'bad');
      else if (r.result.skipped) toast(r.result.reason, 'bad');
      else toast(r.result.issued ? `${plural(r.result.issued, 'new certificate')} issued` : 'No new responses');
      load();
    } catch (err) {
      toast(errorMessage(err), 'bad');
    } finally {
      setSyncing(false);
    }
  }

  if (!data) return error ? <ErrorNote>{error}</ErrorNote> : <Spinner />;
  const { counts, google } = data;

  return (
    <>
      <PageHeader
        title="Overview"
        description={
          google.connected
            ? `Checking Google Form for new responses automatically. Last checked ${timeAgo(google.lastSyncAt)}.`
            : 'Set up takes two steps: connect your Google Form, then create your first event.'
        }
        actions={
          google.connected ? (
            <Button variant="secondary" icon={RefreshCw} loading={syncing} onClick={syncNow}>
              Check for responses now
            </Button>
          ) : null
        }
      />

      {!google.connected ? <ConnectBanner /> : null}
      {google.connected && google.scriptVersion < google.latestScriptVersion ? (
        <Card className="mb-6 flex flex-wrap items-center justify-between gap-4 border-gold/40 bg-gold-wash px-6 py-4">
          <p className="text-[15px] text-ink-soft">
            <b className="text-ink">Update your Google script</b> so participants can verify their certificate by scanning its QR code on their phone.
          </p>
          <Link to="/settings"><Button size="sm">Show me how</Button></Link>
        </Card>
      ) : null}
      {google.lastSyncError ? (
        <div className="mb-6">
          <ErrorNote>
            Couldn't read the Google Form: {google.lastSyncError}{' '}
            <Link to="/settings" className="font-semibold underline">Open Settings</Link>
          </ErrorNote>
        </div>
      ) : null}

      <Pipeline counts={counts} />

      {data.issues.length ? <Issues issues={data.issues} events={allEvents} onChanged={load} /> : null}

      <div className="mt-6 grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <Card>
          <div className="flex items-center justify-between border-b border-line px-6 py-4">
            <h2 className="font-semibold">Latest certificates</h2>
            <Link to="/certificates" className="text-sm font-medium text-blue hover:underline">View all</Link>
          </div>
          {data.recentCertificates.length ? (
            <ul className="divide-y divide-line">
              {data.recentCertificates.map((c) => (
                <li key={c._id} className="flex items-center justify-between gap-3 px-6 py-3">
                  <div className="min-w-0">
                    <p className="truncate font-medium">{c.participant.name}</p>
                    <p className="truncate text-sm text-muted">{c.eventSnapshot.name}, {timeAgo(c.issuedAt)}</p>
                  </div>
                  <DeliveryBadge cert={c} />
                </li>
              ))}
            </ul>
          ) : (
            <EmptyState title="No certificates yet">They appear here as soon as participants submit the form.</EmptyState>
          )}
        </Card>

        <Card>
          <div className="flex items-center justify-between border-b border-line px-6 py-4">
            <h2 className="font-semibold">Events</h2>
            <Link to="/events" className="text-sm font-medium text-blue hover:underline">Manage</Link>
          </div>
          {data.events.length ? (
            <ul className="divide-y divide-line">
              {data.events.map((ev) => (
                <li key={ev._id}>
                  <Link to={`/events/${ev._id}`} className="flex items-center justify-between gap-3 px-6 py-3 hover:bg-canvas">
                    <div className="min-w-0">
                      <p className="truncate font-medium">{ev.name}</p>
                      <p className="text-sm text-muted">{fmtDate(ev.date)}</p>
                    </div>
                    <span className="shrink-0 text-sm tabular-nums text-muted">{plural(ev.stats.certificatesIssued, 'cert')}</span>
                  </Link>
                </li>
              ))}
            </ul>
          ) : (
            <EmptyState
              icon={CalendarPlus}
              title="No events yet"
              action={<Link to="/events?new=1"><Button size="sm">Create event</Button></Link>}
            >
              Create one to get its QR code.
            </EmptyState>
          )}
        </Card>
      </div>
    </>
  );
}
