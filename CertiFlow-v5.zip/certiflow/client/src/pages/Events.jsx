import { useEffect, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router';
import { CalendarPlus, MapPin } from 'lucide-react';
import { api, errorMessage } from '../lib/api.js';
import { fmtDate } from '../lib/format.js';
import { Badge, Button, Card, EmptyState, ErrorNote, PageHeader, Spinner, useToast } from '../components/ui.jsx';
import EventForm from '../components/EventForm.jsx';

export default function Events() {
  const toast = useToast();
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();
  const [events, setEvents] = useState(null);
  const [error, setError] = useState('');
  const creating = params.get('new') === '1';

  useEffect(() => {
    api.get('/events').then((r) => setEvents(r.data.events)).catch((e) => setError(errorMessage(e)));
  }, []);

  const closeForm = () => setParams({});

  return (
    <>
      <PageHeader
        title="Events"
        description="Each event gets its own QR code. Participants scan it after the event to give feedback and receive their certificate."
        actions={<Button icon={CalendarPlus} onClick={() => setParams({ new: '1' })}>New event</Button>}
      />
      <ErrorNote>{error}</ErrorNote>

      {!events ? (
        error ? null : <Spinner />
      ) : events.length === 0 ? (
        <Card>
          <EmptyState icon={CalendarPlus} title="No events yet" action={<Button onClick={() => setParams({ new: '1' })}>Create your first event</Button>}>
            Add the event name, date and who signs the certificate.
          </EmptyState>
        </Card>
      ) : (
        <Card className="overflow-x-auto">
          <table className="w-full min-w-[640px] text-left text-[15px]">
            <thead className="border-b border-line text-sm text-muted">
              <tr>
                <th className="px-6 py-3 font-medium">Event</th>
                <th className="px-4 py-3 font-medium">Date</th>
                <th className="px-4 py-3 text-right font-medium">Feedback</th>
                <th className="px-4 py-3 text-right font-medium">Certificates</th>
                <th className="px-6 py-3 font-medium">Form</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {events.map((ev) => (
                <tr key={ev._id} className="cursor-pointer hover:bg-canvas" onClick={() => navigate(`/events/${ev._id}`)}>
                  <td className="px-6 py-3.5">
                    <Link to={`/events/${ev._id}`} className="font-semibold text-ink hover:text-blue" onClick={(e) => e.stopPropagation()}>
                      {ev.name}
                    </Link>
                    <p className="flex items-center gap-1 text-sm text-muted">
                      {ev.organizer}
                      {ev.venue ? (
                        <>
                          <MapPin className="ml-2 size-3.5" /> {ev.venue}
                        </>
                      ) : null}
                    </p>
                  </td>
                  <td className="whitespace-nowrap px-4 py-3.5 text-ink-soft">{fmtDate(ev.date)}</td>
                  <td className="px-4 py-3.5 text-right tabular-nums">{ev.stats.feedbackCount}</td>
                  <td className="px-4 py-3.5 text-right tabular-nums">{ev.stats.certificatesIssued}</td>
                  <td className="px-6 py-3.5">{ev.feedbackOpen ? <Badge tone="ok">Open</Badge> : <Badge>Closed</Badge>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}

      <EventForm
        open={creating}
        onClose={closeForm}
        onSaved={(data) => {
          if (data.designError) toast(`Event created, but the design image failed: ${data.designError}. Upload it again under Certificate design.`, 'bad');
          else if (data.uploadedDesign) toast('Event created. Now drag the name and date into place under Certificate design.');
          else toast(data.adoptedResponses ? `Event created. ${data.adoptedResponses} waiting response(s) got their certificates.` : 'Event created');
          navigate(`/events/${data.event._id}${data.uploadedDesign || data.designError ? '#design' : ''}`);
        }}
      />
    </>
  );
}
