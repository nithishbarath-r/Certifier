import { useCallback, useEffect, useState } from 'react';
import { Check, Copy, ExternalLink, KeyRound, Link2, RefreshCw, Unplug, UserPlus, X } from 'lucide-react';
import { api, errorMessage } from '../lib/api.js';
import { useAuth } from '../lib/auth.jsx';
import { timeAgo } from '../lib/format.js';
import { Badge, Button, Card, ErrorNote, Field, Input, PageHeader, Select, Spinner, useToast } from '../components/ui.jsx';

function Step({ n, title, done, children }) {
  return (
    <li className="flex gap-4">
      <span
        className={`mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-full font-serif text-[15px] font-semibold ${
          done ? 'bg-ok text-white' : 'border border-gold/60 text-gold'
        }`}
      >
        {done ? <Check className="size-4" strokeWidth={3} /> : n}
      </span>
      <div className="min-w-0 flex-1 pb-8">
        <p className="font-semibold">{title}</p>
        <div className="mt-1.5 space-y-3 text-[15px] text-ink-soft">{children}</div>
      </div>
    </li>
  );
}

function GoogleSetup({ settings, onChange }) {
  const toast = useToast();
  const { admin } = useAuth();
  const g = settings.google;
  const [copied, setCopied] = useState(false);
  const [url, setUrl] = useState('');
  const [busy, setBusy] = useState('');
  const [error, setError] = useState('');

  async function copyScript() {
    let script;
    try {
      ({ data: script } = await api.get('/settings/google/script', { responseType: 'text' }));
    } catch (err) {
      toast(errorMessage(err), 'bad');
      return;
    }
    try {
      await navigator.clipboard.writeText(script);
      toast('Script copied');
    } catch {
      // Clipboard blocked (e.g. opened over a network address): save it as a file instead
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([script], { type: 'text/plain' }));
      a.download = 'CertiFlow-Code.gs';
      a.click();
      toast('Clipboard is blocked here, so the script was downloaded. Open the file and copy all of it.');
    }
    setCopied(true);
  }

  async function connect(e) {
    e.preventDefault();
    setBusy('connect');
    setError('');
    try {
      const { data } = await api.put('/settings/google', { scriptUrl: url.trim() });
      onChange({ ...settings, google: data.google });
      toast('Google Form connected');
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy('');
    }
  }

  async function test() {
    setBusy('test');
    try {
      const { data } = await api.post('/settings/google/test');
      onChange({ ...settings, google: data.google });
      toast('Connection works');
    } catch (err) {
      toast(errorMessage(err), 'bad');
    } finally {
      setBusy('');
    }
  }

  async function disconnect() {
    if (!window.confirm('Disconnect the Google Form? Certificates already issued stay safe.')) return;
    const { data } = await api.delete('/settings/google');
    onChange({ ...settings, google: data.google });
  }

  if (g.connected) {
    return (
      <Card className="p-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-semibold">Google Form</h2>
              <Badge tone="ok">Connected</Badge>
            </div>
            <p className="mt-1 text-[15px] text-muted">
              {g.formTitle}. Last checked {timeAgo(g.lastSyncAt)}.
              {settings.mailMode === 'google' && g.emailQuota != null ? ` About ${g.emailQuota} emails left today on this Gmail account.` : ''}
            </p>
            {g.lastSyncError ? <div className="mt-3"><ErrorNote>{g.lastSyncError}</ErrorNote></div> : null}
          </div>
          <div className="flex flex-wrap gap-2">
            {g.formUrl ? <a href={g.formUrl} target="_blank" rel="noreferrer"><Button size="sm" variant="secondary" icon={ExternalLink}>Open form</Button></a> : null}
            {g.editUrl ? <a href={g.editUrl} target="_blank" rel="noreferrer"><Button size="sm" variant="secondary" icon={ExternalLink}>Edit form</Button></a> : null}
            {g.registerUrl ? <a href={g.registerUrl} target="_blank" rel="noreferrer"><Button size="sm" variant="secondary" icon={ExternalLink}>Certificate register</Button></a> : null}
            <Button size="sm" variant="secondary" icon={RefreshCw} loading={busy === 'test'} onClick={test}>Test connection</Button>
            {admin.role === 'admin' ? <Button size="sm" variant="danger" icon={Unplug} onClick={disconnect}>Disconnect</Button> : null}
          </div>
        </div>

        {g.scriptVersion < g.latestScriptVersion ? (
          <div className="mt-5 rounded-lg border border-gold/40 bg-gold-wash p-4">
            <p className="font-semibold">Update your Google script (2 minutes)</p>
            <p className="mt-1 text-sm text-ink-soft">
              The new version lets anyone check a certificate by scanning its QR code with their phone. Right now the QR only works on this laptop.
            </p>
            <ol className="mt-3 list-decimal space-y-1.5 pl-5 text-sm text-ink-soft">
              <li>
                <button type="button" onClick={copyScript} className="font-semibold text-blue hover:underline">Copy the new script</button>
                {copied ? ' (copied)' : ''}.
              </li>
              <li>In your Apps Script project, select all the old code (Ctrl + A), paste (Ctrl + V) and save (Ctrl + S).</li>
              <li>Select <b>setup</b> next to Run and click <b>Run</b>. Allow the new permission (Google Sheets).</li>
              <li><b>Deploy → Manage deployments → ✏️ Edit</b>, set <b>Version: New version</b>, click <b>Deploy</b>. The link stays the same.</li>
              <li>Click <b>Test connection</b> above. This notice disappears when it worked.</li>
              <li>Open each event that already has certificates and click <b>Re-create certificates</b>, so their QR codes use the new verify page.</li>
            </ol>
          </div>
        ) : null}
        <p className="mt-5 rounded-lg bg-canvas px-4 py-3 text-sm text-ink-soft">
          Don't rename the questions in the Google Form. CertiFlow reads answers by their titles. You can change the description,
          colours and header image freely.
        </p>
      </Card>
    );
  }

  return (
    <Card className="p-6">
      <h2 className="text-lg font-semibold">Connect your Google Form</h2>
      <p className="mt-1 text-[15px] text-muted">
        Do this once, signed in to the Gmail account that should send the certificates. It takes about three minutes.
      </p>
      <ol className="mt-6">
        <Step n={1} title="Copy the CertiFlow script" done={copied}>
          <p>It already contains your app's secret key.</p>
          <Button icon={copied ? Check : Copy} variant={copied ? 'secondary' : 'primary'} onClick={copyScript}>
            {copied ? 'Copied' : 'Copy script'}
          </Button>
        </Step>
        <Step n={2} title="Paste it into a new Apps Script project">
          <p>
            Open{' '}
            <a href="https://script.new" target="_blank" rel="noreferrer" className="font-semibold text-blue hover:underline">script.new</a>
            , delete the sample code, paste, and press <b>Ctrl + S</b> to save.
          </p>
        </Step>
        <Step n={3} title="Run setup to create your form">
          <p>
            Make sure <b>setup</b> is selected next to the Run button, then click <b>Run</b>. Google asks for permission: choose your
            account, then <b>Advanced</b>, <b>Go to project</b>, <b>Allow</b>. This is your own script, so it's safe.
          </p>
        </Step>
        <Step n={4} title="Deploy it as a web app">
          <p>
            Click <b>Deploy</b>, <b>New deployment</b>, the gear icon, <b>Web app</b>. Set <b>Execute as: Me</b> and{' '}
            <b>Who has access: Anyone</b>, then <b>Deploy</b> and copy the <b>Web app URL</b>.
          </p>
        </Step>
        <Step n={5} title="Paste the Web app URL here">
          <form onSubmit={connect} className="flex flex-col gap-2 sm:flex-row">
            <Input
              placeholder="https://script.google.com/macros/s/…/exec"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              aria-label="Web app URL"
              required
            />
            <Button type="submit" icon={Link2} loading={busy === 'connect'} className="shrink-0">Connect</Button>
          </form>
          <ErrorNote>{error}</ErrorNote>
        </Step>
      </ol>
    </Card>
  );
}

function PasswordCard() {
  const toast = useToast();
  const [form, setForm] = useState({ currentPassword: '', newPassword: '' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  async function save(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      await api.post('/auth/change-password', form);
      setForm({ currentPassword: '', newPassword: '' });
      toast('Password changed');
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }
  return (
    <Card className="p-6">
      <h2 className="flex items-center gap-2 text-lg font-semibold"><KeyRound className="size-5 text-muted" /> Your password</h2>
      <form onSubmit={save} className="mt-4 space-y-3">
        <Field label="Current password">
          <Input type="password" autoComplete="current-password" value={form.currentPassword} onChange={(e) => setForm({ ...form, currentPassword: e.target.value })} required />
        </Field>
        <Field label="New password" hint="At least 8 characters">
          <Input type="password" autoComplete="new-password" minLength={8} value={form.newPassword} onChange={(e) => setForm({ ...form, newPassword: e.target.value })} required />
        </Field>
        <ErrorNote>{error}</ErrorNote>
        <Button type="submit" loading={busy}>Change password</Button>
      </form>
    </Card>
  );
}

function TeamCard() {
  const toast = useToast();
  const { admin } = useAuth();
  const [users, setUsers] = useState([]);
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'coordinator' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const load = useCallback(() => api.get('/auth/users').then((r) => setUsers(r.data.users)).catch(() => {}), []);
  useEffect(() => { load(); }, [load]);

  async function add(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      await api.post('/auth/users', form);
      toast(`${form.name} can now log in`);
      setForm({ name: '', email: '', password: '', role: 'coordinator' });
      load();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }
  async function remove(u) {
    if (!window.confirm(`Remove ${u.name}'s access?`)) return;
    try {
      await api.delete(`/auth/users/${u.id}`);
      load();
    } catch (err) {
      toast(errorMessage(err), 'bad');
    }
  }

  return (
    <Card className="p-6">
      <h2 className="flex items-center gap-2 text-lg font-semibold"><UserPlus className="size-5 text-muted" /> Team</h2>
      <p className="mt-1 text-sm text-muted">Coordinators can manage events and certificates. Admins can also change the Google connection and team.</p>
      <ul className="mt-4 divide-y divide-line rounded-lg border border-line">
        {users.map((u) => (
          <li key={u.id} className="flex items-center justify-between gap-3 px-4 py-2.5">
            <div className="min-w-0">
              <p className="truncate text-sm font-medium">{u.name} {u.id === admin.id ? <span className="text-muted">(you)</span> : null}</p>
              <p className="truncate text-xs text-muted">{u.email}</p>
            </div>
            <div className="flex items-center gap-2">
              <Badge tone={u.role === 'admin' ? 'blue' : 'muted'}>{u.role === 'admin' ? 'Admin' : 'Coordinator'}</Badge>
              {u.id !== admin.id ? (
                <button type="button" onClick={() => remove(u)} className="rounded p-1 text-muted hover:text-bad" aria-label={`Remove ${u.name}`}>
                  <X className="size-4" />
                </button>
              ) : null}
            </div>
          </li>
        ))}
      </ul>
      <form onSubmit={add} className="mt-4 grid gap-3 sm:grid-cols-2">
        <Input placeholder="Name" aria-label="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
        <Input type="email" placeholder="Email" aria-label="Email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required />
        <Input type="password" placeholder="Temporary password" aria-label="Temporary password" minLength={8} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} required />
        <Select aria-label="Role" value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
          <option value="coordinator">Coordinator</option>
          <option value="admin">Admin</option>
        </Select>
        <div className="sm:col-span-2"><ErrorNote>{error}</ErrorNote></div>
        <Button type="submit" variant="secondary" icon={UserPlus} loading={busy} className="sm:col-span-2 sm:justify-self-start">Add team member</Button>
      </form>
    </Card>
  );
}

export default function Settings() {
  const { admin } = useAuth();
  const [settings, setSettings] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get('/settings').then((r) => setSettings(r.data)).catch((e) => setError(errorMessage(e)));
  }, []);

  if (error) return <ErrorNote>{error}</ErrorNote>;
  if (!settings) return <Spinner />;

  return (
    <>
      <PageHeader title="Settings" description="Connect Google Form and Gmail, and manage who can log in." />
      <div className="space-y-6">
        <GoogleSetup settings={settings} onChange={setSettings} />
        <div className="grid gap-6 lg:grid-cols-2">
          <PasswordCard />
          {admin.role === 'admin' ? <TeamCard /> : null}
        </div>
        <p className="text-sm text-muted">
          Database: {settings.database === 'local' ? 'stored on this computer (server/.data)' : 'MongoDB Atlas'}.
          Emails are sent {settings.mailMode === 'smtp' ? 'through your SMTP settings' : 'from the connected Gmail account'}.
          Verification links point to {settings.publicBaseUrl}.
        </p>
      </div>
    </>
  );
}
