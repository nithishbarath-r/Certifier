# CertiFlow — Event Feedback & Automated E-Certificate System

## Aim

To design and develop a web application that collects event feedback through a QR code and Google Form,
automatically generates a personalised e-certificate for every participant, emails it to them, and stores every
certificate with its details in a database where it can be verified.

## Software requirements

| Item | Version / detail |
|---|---|
| Operating system | Windows 10/11, macOS or Linux |
| Runtime | Node.js 20.19 or newer (LTS recommended) |
| Database | MongoDB 8 (started automatically on the laptop) or MongoDB Atlas |
| Backend | Node.js, Express 5, Mongoose 9, PDFKit, QRCode, JSON Web Token, bcrypt |
| Frontend | React 19, Vite, Tailwind CSS 4, React Router, Axios |
| Google | Google Form, Google Apps Script, Gmail (MailApp), Google Sheets |
| Editor | Visual Studio Code |

## Modules

1. **Authentication**: coordinator login with JWT and bcrypt, admin and coordinator roles.
2. **Event management**: create events, choose the certificate design, generate a QR code with the event pre-filled.
3. **Google Form integration**: an Apps Script creates the form; CertiFlow reads new responses every 30 seconds.
4. **Certificate generation**: a PDF is drawn on the club's design with the name, date, certificate ID and verify QR,
   then stored inside MongoDB using GridFS.
5. **Email delivery**: the certificate is sent from the coordinator's Gmail with automatic retries.
6. **Dashboard and analytics**: totals, ratings, reviews, Excel export, and responses that need attention.
7. **Verification**: a public page where anyone can check a certificate by scanning its QR code.

## Procedure

### Part A: Install and start (one time)

1. Install Node.js LTS from https://nodejs.org.
2. Extract the CertiFlow zip, for example to `N:\cert`. The project is in `N:\cert\certiflow`.
3. Start the app in one of two ways:
   - Double-click `start-windows.bat`, or
   - In VS Code, open the `certiflow` folder, then run `cd server`, `npm install` and `npm run dev` in the terminal.
4. Wait for **"✅ CertiFlow is running"** and open http://localhost:5000.
5. Log in with `admin@certiflow.local` / `Admin@123`. Change the password in **Settings**.

### Part B: Connect the Google Form (one time)

6. In **Settings**, click **Copy script**.
7. Open https://script.new (signed in with a personal Gmail account), delete the sample code, paste, and save.
8. Select **setup** and click **Run**. Allow the permissions. This creates the Google Form and the
   **CertiFlow Certificate Register** Google Sheet.
9. Click **Deploy → New deployment → Web app**. Set **Execute as: Me** and **Who has access: Anyone**, then click **Deploy**.
10. Copy the Web app URL, paste it in **Settings**, and click **Connect**. The status shows **Connected**.

### Part C: Prepare an event

11. Go to **Events → New event**. Enter the name (e.g. *Query Quest*), the organiser and the date.
    Choose the certificate design (**RMKCET – Query Quest** is selected by default), then click **Create event**.
12. On the event page, click **Preview certificate PDF** to check the certificate.
13. Click **Print poster** or **Save QR** to get the QR code.

### Part D: During and after the event

14. Display the QR code. Participants scan it, and the Google Form opens with the event name already filled in.
15. Participants enter their name, register number, college, email, rating and review, then submit.
16. Within about 30 seconds CertiFlow automatically:
    - saves the feedback in MongoDB,
    - generates the PDF certificate on the selected design,
    - stores the PDF in MongoDB (GridFS) with the participant's details,
    - emails the certificate to the participant,
    - adds it to the Google Sheet register used by the public verify page.
17. Check the results:
    - **Overview** shows totals and any responses that need attention.
    - The **event page** shows ratings and reviews; use **Export to Excel** for records.
    - **Certificates** lets you view, download, re-send or revoke certificates.
18. Anyone can scan the QR code printed on a certificate to confirm it is genuine.

### Part E: Testing

19. In the VS Code terminal, inside the `server` folder, run `npm test`.
    30 automated tests check the complete flow (login, events, form responses, certificates, email, verification,
    re-creating certificates, Gmail limits). All should report `ok`.

## Database collections

| Collection | Stores |
|---|---|
| `events` | event details, certificate design settings, counters |
| `feedbacks` | each form submission: name, register no, college, email, rating, review |
| `certificates` | certificate ID, participant and event details, email status, validity |
| `certificates.files` / `certificates.chunks` | the certificate PDFs (GridFS) |
| `templates.files` / `templates.chunks` | the certificate design images (GridFS) |
| `admins` | coordinator logins (passwords hashed with bcrypt) |
| `syncissues` | responses that could not be processed automatically |
| `settings` | Google connection and app settings |

## Result

The system was developed and tested successfully. After a participant scans the QR code and submits the Google
Form, a personalised certificate on the club's design is generated, emailed and stored in the database within about
30 seconds, and it can be verified by anyone by scanning the QR code on the certificate.
