// Sends the certificate email. Uses SMTP if SMTP_USER is set in .env,
// otherwise sends through the coordinator's Gmail via the Google script.
import nodemailer from 'nodemailer';
import { env } from '../config/env.js';
import { getSetting } from '../models/index.js';
import { sendEmailViaGoogle } from './googleBridge.js';

let transporter = null;
const smtpEnabled = () => Boolean(env.smtp.user && env.smtp.pass);

export const mailMode = () => (smtpEnabled() ? 'smtp' : 'google');

const escapeHtml = (s) =>
  String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

export function buildCertificateEmail({ participant, event, certificateId, verifyUrl }) {
  const subject = `Your certificate for ${event.name}`;
  const text =
    `Hi ${participant.name},\n\nThank you for attending ${event.name} and sharing your feedback.\n` +
    `Your certificate is attached.\n\nCertificate ID: ${certificateId}\nVerify it at: ${verifyUrl}\n\n— ${event.organizer}`;
  const html = `
  <div style="font-family:Arial,Helvetica,sans-serif;max-width:560px;margin:0 auto;color:#1B2340">
    <div style="border-top:4px solid #2643B9;padding:24px 4px">
      <p style="font-size:15px">Hi ${escapeHtml(participant.name)},</p>
      <p style="font-size:15px;line-height:1.6">Thank you for attending <b>${escapeHtml(event.name)}</b> and sharing your feedback.
      Your certificate is attached to this email as a PDF.</p>
      <table style="font-size:14px;margin:18px 0;border-collapse:collapse">
        <tr><td style="color:#5B6275;padding:4px 16px 4px 0">Certificate ID</td><td><b>${escapeHtml(certificateId)}</b></td></tr>
        <tr><td style="color:#5B6275;padding:4px 16px 4px 0">Event</td><td>${escapeHtml(event.name)}</td></tr>
      </table>
      <p style="font-size:14px">Anyone can check that it's genuine here:<br>
      <a href="${verifyUrl}" style="color:#2643B9">${escapeHtml(verifyUrl)}</a></p>
      <p style="font-size:14px;color:#5B6275;margin-top:28px">— ${escapeHtml(event.organizer)}</p>
    </div>
  </div>`;
  return { subject, text, html };
}

export async function sendMail({ to, subject, html, text, attachments = [], senderName }) {
  if (smtpEnabled()) {
    transporter ??= nodemailer.createTransport({
      host: env.smtp.host,
      port: env.smtp.port,
      secure: env.smtp.port === 465,
      auth: { user: env.smtp.user, pass: env.smtp.pass },
    });
    await transporter.sendMail({
      from: env.smtp.from || `"${senderName || 'CertiFlow'}" <${env.smtp.user}>`,
      to,
      subject,
      html,
      text,
      attachments: attachments.map((a) => ({ filename: a.filename, content: a.content, contentType: a.contentType })),
    });
    return { via: 'smtp' };
  }

  const scriptUrl = await getSetting('google.scriptUrl');
  const result = await sendEmailViaGoogle(scriptUrl, {
    to,
    subject,
    html,
    text,
    senderName,
    attachments: attachments.map((a) => ({
      filename: a.filename,
      contentType: a.contentType,
      base64: a.content.toString('base64'),
    })),
  });
  return { via: 'google', emailQuota: result.emailQuota };
}
