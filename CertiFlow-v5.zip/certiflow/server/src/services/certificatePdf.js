// Draws the certificate as an A4 landscape PDF using PDFKit's built-in fonts
// (no font files needed). Returns a Buffer.
import PDFDocument from 'pdfkit';
import QRCode from 'qrcode';

const C = {
  ink: '#1B2340',
  muted: '#5B6275',
  blue: '#2643B9',
  gold: '#B9861C',
  paper: '#FFFFFF',
  wash: '#F3F5FC',
};

const fmtDate = (d) =>
  new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'Asia/Kolkata' });

// Shrinks text until it fits the given width
function fitFontSize(doc, text, font, maxSize, minSize, width) {
  let size = maxSize;
  doc.font(font);
  while (size > minSize && doc.fontSize(size).widthOfString(text) > width) size -= 1;
  return size;
}

export async function renderCertificatePdf({ certificateId, participant, event, verifyUrl, title, signatories = [] }) {
  const qrPng = await QRCode.toBuffer(verifyUrl, { margin: 0, width: 220, color: { dark: C.ink, light: '#FFFFFF' } });

  const doc = new PDFDocument({
    size: 'A4',
    layout: 'landscape',
    margin: 0,
    info: { Title: `${title} — ${participant.name}`, Author: event.organizer, Subject: event.name, Keywords: certificateId },
  });
  const chunks = [];
  doc.on('data', (c) => chunks.push(c));
  const done = new Promise((resolve) => doc.on('end', () => resolve(Buffer.concat(chunks))));

  const W = doc.page.width; // 841.89
  const H = doc.page.height; // 595.28
  const cx = W / 2;

  // Background + frame
  doc.rect(0, 0, W, H).fill(C.paper);
  doc.rect(0, 0, 18, H).fill(C.blue);
  doc.rect(18, 0, 4, H).fill(C.gold);
  doc.lineWidth(1).strokeColor(C.gold).rect(42, 26, W - 68, H - 52).stroke();
  doc.lineWidth(0.4).strokeColor(C.blue).rect(48, 32, W - 80, H - 64).stroke();

  // Seal (top right)
  const sx = W - 112, sy = 96;
  doc.circle(sx, sy, 38).fill(C.blue);
  doc.circle(sx, sy, 33).lineWidth(1).strokeColor('#FFFFFF').stroke();
  doc.fillColor('#FFFFFF').font('Helvetica-Bold').fontSize(9).text('VERIFIED', sx - 30, sy - 9, { width: 60, align: 'center' });
  doc.font('Helvetica').fontSize(7).text(new Date().getFullYear().toString(), sx - 30, sy + 3, { width: 60, align: 'center' });

  const contentX = 90;
  const contentW = W - 180;

  // Organizer
  doc.fillColor(C.muted).font('Helvetica').fontSize(12)
    .text(event.organizer, contentX, 70, { width: contentW, align: 'center', characterSpacing: 1 });

  // Title
  doc.fillColor(C.ink).font('Times-Bold').fontSize(36)
    .text(title, contentX, 98, { width: contentW, align: 'center' });

  doc.moveTo(cx - 60, 150).lineTo(cx + 60, 150).lineWidth(1.5).strokeColor(C.gold).stroke();

  doc.fillColor(C.muted).font('Times-Italic').fontSize(15)
    .text('This is to certify that', contentX, 172, { width: contentW, align: 'center' });

  // Participant name
  const nameSize = fitFontSize(doc, participant.name, 'Times-BoldItalic', 40, 22, contentW - 40);
  doc.fillColor(C.blue).font('Times-BoldItalic').fontSize(nameSize)
    .text(participant.name, contentX, 200, { width: contentW, align: 'center' });
  doc.moveTo(cx - 190, 252).lineTo(cx + 190, 252).lineWidth(0.6).strokeColor(C.ink).stroke();

  // Details
  doc.fillColor(C.ink).font('Times-Roman').fontSize(15);
  const line1 = `Register No. ${participant.regNo}, ${participant.college},`;
  doc.text(line1, contentX, 268, { width: contentW, align: 'center' });
  doc.text('has successfully participated in', contentX, 292, { width: contentW, align: 'center' });

  const eventSize = fitFontSize(doc, event.name, 'Times-Bold', 22, 14, contentW - 40);
  doc.font('Times-Bold').fontSize(eventSize).fillColor(C.ink)
    .text(event.name, contentX, 318, { width: contentW, align: 'center' });

  doc.font('Times-Roman').fontSize(15).fillColor(C.ink)
    .text(`organised by ${event.organizer} on ${fmtDate(event.date)}${event.venue ? `, ${event.venue}` : ''}.`,
      contentX, 350, { width: contentW, align: 'center' });

  // Signatories (bottom), up to 3
  const sigs = signatories.slice(0, 3);
  if (sigs.length) {
    const slotW = 190;
    const gap = sigs.length > 1 ? (contentW - 120 - slotW * sigs.length) / (sigs.length - 1) : 0;
    const startX = sigs.length === 1 ? W - 90 - slotW - 40 : contentX + 120;
    sigs.forEach((s, i) => {
      const x = startX + i * (slotW + gap);
      doc.moveTo(x + 15, 468).lineTo(x + slotW - 15, 468).lineWidth(0.6).strokeColor(C.ink).stroke();
      doc.fillColor(C.ink).font('Helvetica-Bold').fontSize(10.5).text(s.name, x, 475, { width: slotW, align: 'center' });
      doc.fillColor(C.muted).font('Helvetica').fontSize(9).text(s.designation, x, 489, { width: slotW, align: 'center' });
    });
  }

  // Verification block (bottom left)
  doc.image(qrPng, 72, 432, { width: 66 });
  doc.fillColor(C.muted).font('Helvetica').fontSize(7.5).text('Certificate ID', 72, 504);
  doc.fillColor(C.ink).font('Helvetica-Bold').fontSize(9).text(certificateId, 72, 514);
  doc.fillColor(C.muted).font('Helvetica').fontSize(7)
    .text('Scan to verify', 72, 527);

  doc.end();
  return done;
}
