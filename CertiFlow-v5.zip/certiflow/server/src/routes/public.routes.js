import { Router } from 'express';
import { Certificate } from '../models/index.js';
import { ApiError } from '../utils/ApiError.js';

const router = Router();

// Anyone can check a certificate is genuine using its ID (no login)
router.get('/verify/:certificateId', async (req, res) => {
  const id = String(req.params.certificateId || '').trim().toUpperCase();
  if (!/^CF-\d{4}-[A-Z0-9]{6}$/.test(id)) throw ApiError.badRequest('That does not look like a CertiFlow certificate ID (e.g. CF-2026-7K3QXM)');

  const cert = await Certificate.findOne({ certificateId: id }).lean();
  if (!cert) return res.status(404).json({ success: false, valid: false, message: 'No certificate exists with this ID' });

  const reg = cert.participant.regNo;
  res.json({
    success: true,
    valid: cert.status === 'active',
    certificate: {
      certificateId: cert.certificateId,
      status: cert.status,
      name: cert.participant.name,
      // Partially hidden so the public page doesn't expose full register numbers
      regNo: reg.length > 4 ? `${'•'.repeat(reg.length - 4)}${reg.slice(-4)}` : reg,
      college: cert.participant.college,
      event: cert.eventSnapshot.name,
      eventDate: cert.eventSnapshot.date,
      organizer: cert.eventSnapshot.organizer,
      issuedAt: cert.issuedAt,
    },
  });
});

export default router;
