import { Router } from 'express';
import mongoose from 'mongoose';
import QRCode from 'qrcode';
import { Event, Feedback, Certificate, REVIEW_OPTIONS, getSettings, nameKeyOf } from '../models/index.js';
import { requireAuth } from '../middleware/auth.js';
import { prefilledFormUrl } from '../services/googleBridge.js';
import { adoptWaitingResponses } from '../services/syncService.js';
import { applyPreset } from '../services/designService.js';
import { deleteTemplate } from '../services/gridfs.js';
import { ApiError } from '../utils/ApiError.js';
import { toCsv } from '../utils/csv.js';

const router = Router();
router.use(requireAuth);

const EDITABLE = ['name', 'description', 'organizer', 'venue', 'date', 'formUrl', 'feedbackOpen', 'certificate'];

function pickEditable(body = {}) {
  const out = {};
  for (const key of EDITABLE) if (body[key] !== undefined) out[key] = body[key];
  if (out.certificate) {
    out.certificate = {
      title: String(out.certificate.title || 'Certificate of Participation').trim(),
      signatories: (out.certificate.signatories || [])
        .filter((s) => s && String(s.name || '').trim() && String(s.designation || '').trim())
        .slice(0, 3)
        .map((s) => ({ name: String(s.name).trim(), designation: String(s.designation).trim() })),
    };
  }
  return out;
}

async function formLinkFor(event) {
  if (event.formUrl) return event.formUrl;
  const g = await getSettings(['google.formUrl', 'google.eventEntryId']);
  return prefilledFormUrl(g['google.formUrl'], g['google.eventEntryId'], event.name);
}

async function findEvent(id) {
  if (!mongoose.isValidObjectId(id)) throw ApiError.notFound('Event not found');
  const event = await Event.findById(id);
  if (!event) throw ApiError.notFound('Event not found');
  return event;
}

router.get('/', async (req, res) => {
  const events = await Event.find().sort({ date: -1 }).lean();
  res.json({ success: true, events });
});

router.post('/', async (req, res) => {
  const data = pickEditable(req.body);
  if (await Event.exists({ nameKey: nameKeyOf(data.name) })) {
    throw ApiError.conflict('An event with this name already exists. Event names must be unique so form answers match the right event.');
  }
  const event = await Event.create({ ...data, createdBy: req.admin._id });
  // Ready-made certificate design chosen in the New event form (applied before any certificate is made)
  if (req.body?.designPreset) {
    try {
      await applyPreset(event, req.body.designPreset);
    } catch (err) {
      await event.deleteOne();
      throw err;
    }
  }
  // When the coordinator will upload their own design next, don't issue waiting certificates yet
  const adopted = req.body?.uploadingDesign ? 0 : await adoptWaitingResponses(event);
  res.status(201).json({ success: true, event: await Event.findById(event._id).lean(), adoptedResponses: adopted });
});

router.get('/:id', async (req, res) => {
  const event = await findEvent(req.params.id);
  res.json({ success: true, event, formLink: await formLinkFor(event) });
});

router.patch('/:id', async (req, res) => {
  const event = await findEvent(req.params.id);
  const data = pickEditable(req.body);
  if (data.name && nameKeyOf(data.name) !== event.nameKey && (await Event.exists({ nameKey: nameKeyOf(data.name) }))) {
    throw ApiError.conflict('Another event already uses this name');
  }
  // Set certificate title/signatures individually so the design settings are kept
  const { certificate, ...rest } = data;
  Object.assign(event, rest);
  if (certificate) {
    event.set('certificate.title', certificate.title);
    event.set('certificate.signatories', certificate.signatories);
  }
  await event.save();
  res.json({ success: true, event, formLink: await formLinkFor(event) });
});

router.delete('/:id', async (req, res) => {
  const event = await findEvent(req.params.id);
  if (await Certificate.exists({ event: event._id })) {
    throw ApiError.conflict('This event has issued certificates, so it cannot be deleted. Close feedback instead.');
  }
  await Feedback.deleteMany({ event: event._id });
  if (event.certificate?.design?.templateFileId) await deleteTemplate(event.certificate.design.templateFileId);
  await event.deleteOne();
  res.json({ success: true });
});

// QR code that opens the Google Form with this event's name already filled in
router.get('/:id/qr', async (req, res) => {
  const event = await findEvent(req.params.id);
  const formLink = await formLinkFor(event);
  if (!formLink) throw ApiError.conflict('Connect your Google Form in Settings first, then the QR code appears here.');
  const qrDataUrl = await QRCode.toDataURL(formLink, { width: 640, margin: 2, errorCorrectionLevel: 'M' });
  res.json({ success: true, formLink, qrDataUrl });
});

router.get('/:id/feedback', async (req, res) => {
  const event = await findEvent(req.params.id);
  const feedback = await Feedback.find({ event: event._id })
    .sort({ submittedAt: -1 })
    .populate('certificate', 'certificateId delivery status')
    .lean();

  const ratingCounts = [1, 2, 3, 4, 5].map((r) => feedback.filter((f) => f.rating === r).length);
  const reviewCounts = Object.fromEntries(REVIEW_OPTIONS.map((o) => [o, feedback.filter((f) => f.review === o).length]));
  const avg = feedback.length ? feedback.reduce((s, f) => s + f.rating, 0) / feedback.length : null;

  res.json({
    success: true,
    feedback,
    analytics: {
      total: feedback.length,
      averageRating: avg == null ? null : Math.round(avg * 10) / 10,
      ratingCounts,
      reviewCounts,
      colleges: [...new Set(feedback.map((f) => f.participant.college))].length,
    },
  });
});

router.get('/:id/export.csv', async (req, res) => {
  const event = await findEvent(req.params.id);
  const rows = await Feedback.find({ event: event._id }).sort({ submittedAt: 1 }).populate('certificate').lean();
  const csv = toCsv(
    [
      { label: 'Submitted at', value: (r) => r.submittedAt },
      { label: 'Name', value: (r) => r.participant.name },
      { label: 'Register No', value: (r) => r.participant.regNo },
      { label: 'College', value: (r) => r.participant.college },
      { label: 'Email', value: (r) => r.participant.email },
      { label: 'Rating', value: (r) => r.rating },
      { label: 'Review', value: (r) => r.review },
      { label: 'Comments', value: (r) => r.comments },
      { label: 'Certificate ID', value: (r) => r.certificate?.certificateId },
      { label: 'Email status', value: (r) => r.certificate?.delivery?.status },
    ],
    rows
  );
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="${event.slug}-feedback.csv"`);
  res.send(csv);
});

export default router;
