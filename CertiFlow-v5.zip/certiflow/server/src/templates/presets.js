// Ready-made certificate designs. Positions are fractions of the image:
// x = horizontal centre of the text, y = text baseline (or top edge for the QR),
// size = font height / QR width as a fraction of the image width.
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));

export const PRESETS = {
  'rmkcet-query-quest': {
    label: 'RMKCET – Query Quest (CSE Student Chapter)',
    file: path.join(here, 'rmkcet-query-quest.jpg'),
    contentType: 'image/jpeg',
    fields: {
      name: { x: 0.6828, y: 0.5176, size: 0.0245, maxWidth: 0.4, color: '#14284B', font: 'cinzel', uppercase: true },
      date: { x: 0.6477, y: 0.6839, size: 0.0158, color: '#15294B', font: 'cormorant', format: 'D MMMM YYYY.' },
      verify: { show: true, x: 0.9128, y: 0.757, size: 0.052 },
    },
  },
};

export const DEFAULT_FIELDS = {
  name: { x: 0.5, y: 0.5, size: 0.035, maxWidth: 0.6, color: '#1B2340', font: 'cinzel', uppercase: true },
  date: { x: 0.5, y: 0.65, size: 0.018, color: '#1B2340', font: 'cormorant', format: 'D MMMM YYYY' },
  verify: { show: true, x: 0.9, y: 0.78, size: 0.06 },
};
